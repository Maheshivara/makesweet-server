class MakeSweetConfig {
  public static var zoom : Float = 1.0;
  public static var width : Int = 400;
  public static var height : Int = 300;
  public static var version : Int = 2;
  public static var logo_left : Int = 0;
  public static var inputs : Int = 1;
  public static var tricky : Int = 0;

  public static var animation : Bool = true;
  public static var frames : Int = 40;
  public static var palette : Array<Int> = [ 0 ];
  public static var delay : Float = 0.099999;
  public static var speed_step : Float = 1;
  public static var hold : Float = 0;
}