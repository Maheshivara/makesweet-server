class MakeSweetConfig {
  public static var zoom : Float = 1.0;
  public static var width : Int = 400;
  public static var height : Int = 300;
  public static var version : Int = 2;
  public static var logo_left : Int = 0;
 
//[all]
//first = 7
//last = 128
//initial = 60
//period = 3
//hold = 0
//speed_step = 1
//palette = [30, 60, 90, 110]
  public static var animation : Bool = true;
  public static var frames : Int = 41;
  public static var palette : Array<Int> = [ 7,17,27,34 ];
  public static var delay : Float = .099999;
  public static var speed_step : Float = 1;
  public static var hold : Float = 0;
}
